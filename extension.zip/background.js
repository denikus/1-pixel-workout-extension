let n = 0;
const g = 900 * 1e3, c = "https://1minuteworkout.org";
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: "/settings.html" });
});
chrome.webNavigation.onBeforeNavigate.addListener((o) => {
  if (console.log("basic url to:", c), o.url === `${c}/back_to_extension`) {
    u(o.tabId);
    return;
  }
  o.frameId === 0 && m(o.url, o.tabId);
});
chrome.runtime.onMessage.addListener((o, e, t) => {
  o.action === "startCooldown" && (l(), t({ success: !0 }));
});
function l() {
  n = Date.now() + g, chrome.storage.local.set({ cooldownUntil: n }, () => {
    console.log("Cooldown persisted until:", new Date(n));
  });
}
async function d() {
  if (Date.now() < n) return !0;
  const { cooldownUntil: o } = await chrome.storage.local.get("cooldownUntil");
  return n = o || 0, Date.now() < n;
}
async function m(o, e) {
  if (await d()) {
    console.log("In cooldown period, allowing navigation");
    return;
  }
  const { triggerSites: t } = await chrome.storage.sync.get("triggerSites"), a = t || [], s = new URL(o).hostname;
  if (a.some((r) => s.includes(r))) {
    console.log("Trigger site visited!:", o);
    const r = encodeURIComponent(o), i = chrome.runtime.getURL(`preworkout.html?original=${r}`);
    console.log("Redirecting to:", i), chrome.tabs.update(e, { url: i });
  }
}
function u(o) {
  chrome.storage.local.get(["originalUrl"], (e) => {
    e.originalUrl ? (console.log("Redirecting back to:", e.originalUrl), l(), chrome.tabs.update(o, { url: e.originalUrl }), chrome.storage.local.remove(["originalUrl"], () => {
      console.log("Original URL removed from storage");
    })) : console.log("No original URL found in storage");
  });
}
