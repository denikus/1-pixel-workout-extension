
				{
					__sveltekit_9cqlat = {
						base: new URL(".", location).pathname.slice(0, -1)
					};

					const element = document.currentScript.parentElement;

					Promise.all([
						import("./app/immutable/entry/start.BMjSEOhZ.js"),
						import("./app/immutable/entry/app.CQkoIuQT.js")
					]).then(([kit, app]) => {
						kit.start(app, element, {
							node_ids: [0, 3],
							data: [null,null],
							form: null,
							error: null
						});
					});
				}
			