import{q as a}from"./afbAfhuZ.js";a();
